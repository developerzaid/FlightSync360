package com.hazyaz.FlightPulse360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightPulse360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
