package com.hazyaz.FlightPulse360;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightPulse360Application {

	public static void main(String[] args) {
		SpringApplication.run(FlightPulse360Application.class, args);
	}

}
